g++	-o	ass_one	-Wall	-Wextra	-Wpedantic Assignment1.cpp -llapack -lblas -O3
./ass_one

python3 plot_part_one.py
python3 plot_part_two.py
python3 plot_part_three.py
python3 plot_part_four.py