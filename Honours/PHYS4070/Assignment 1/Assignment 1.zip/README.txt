All code was written on a Windows machine within WSL2 Ubuntu and VSCode. 
Python is needed to plot the data, but the shell script should compile and run the C++ code, and plot the data no problem by running 
`bash Assignment1.sh` 